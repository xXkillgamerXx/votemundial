<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="text-block">K-POP BOY</div>
        </div>
        <div class="card-body">
            <?php $__currentLoopData = $votations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $votation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <a href="<?php echo e(route('votations.show',$votation->id)); ?>" class="link-block-4 w-inline-block">
                        <div class="div-block-3">
                            <div class="text-block-2"><?php echo e($votation->created_at->format('Y.m.d')); ?></div>
                            <div class="div-block-4">
                                <div class="card-avatar">
                                    <div class="text-block-4">2</div>
                                    <div class="avatar sm">
                                        <img src="<?php echo e($votation->options[1]->photo); ?>" loading="lazy" alt=""></div>
                                    <div class="text-block-3"><strong><?php echo e($votation->options[1]->name); ?></strong></div>
                                </div>
                                <div class="card-avatar">
                                    <div class="text-block-4">1</div>
                                    <div class="avatar">
                                        <img src="<?php echo e($votation->options[0]->photo); ?>" loading="lazy" alt="">
                                    </div>
                                    <div class="text-block-3"><strong><?php echo e($votation->options[0]->name); ?></strong></div>
                                </div>
                                <div class="card-avatar">
                                    <div class="text-block-4">3</div>
                                    <div class="avatar sm">
                                        <img src="<?php echo e($votation->options[2]->photo); ?>" loading="lazy" alt="">
                                    </div>
                                    <div class="text-block-3"><strong><?php echo e($votation->options[2]->name); ?></strong></div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\metkstar\resources\views/home.blade.php ENDPATH**/ ?>